package com.infy.theatreservice;

 

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

 

@Service
public class TheatreService {
    
    @Autowired
    private TheatreRepository repo;

 

    public Theatre addTheatre(Theatre theatre) {
        return repo.save(theatre);
    }

 
 

    public List<Theatre> getTheatre() {
        return (List<Theatre>) repo.findAll();
    }

 

    public Theatre getTheatre(Integer id) {
        return repo.findById(id).get();
    }

 
    public List<Theatre> getTheatreBytheatreName(String theatreName) {
        return (List<Theatre>) repo.findBytheatreName(theatreName);
    }
    
    public void deleteBytheatreId(Integer id) {
        repo.deleteById(id);
        
    }
    
    
    public Theatre updateDetails(Integer id, Theatre theatre) {
        theatre.settheatreId(id);
        return repo.save(theatre);
    }
    
            
}