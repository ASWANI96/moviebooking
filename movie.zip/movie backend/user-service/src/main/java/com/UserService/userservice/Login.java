package com.UserService.userservice;

import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


public class Login {
   
	private String userName;
	private String password;
////	private String role;
////	public String getRole() {
////		return role;
////	}
//	public void setRole(String role) {
//		this.role = role;
//	}
	public String getUsername() {
		return userName;
	}
	public void setUsername(String username) {
		this.userName = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Login() {
		super();
	}

}
