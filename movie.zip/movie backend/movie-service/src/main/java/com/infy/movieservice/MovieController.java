package com.infy.movieservice;



import java.util.List;

import javax.validation.Valid;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class MovieController {
    
    @Autowired
    private MovieService service;
    
    @PostMapping(value ="/add_movie") //work
    public ResponseEntity<Movie> addMovie(@Valid @RequestBody Movie movie){
        return new ResponseEntity<>(service.addMovie(movie),HttpStatus.OK);
    }





    @GetMapping(value ="/AllMovies") //work
    public ResponseEntity<List<Movie>> getMovies(){
        return new ResponseEntity<>(service.getMovies(),HttpStatus.OK);
    }





    @GetMapping(value ="/movie/{id}") //work
    public ResponseEntity<Movie> getMovieById(@PathVariable("id") Integer id){
        return new ResponseEntity<>(service.getMovie(id),HttpStatus.OK);
    }



    @GetMapping(value ="/movie/name/{movieName}") //work
    public ResponseEntity<List<Movie>> getMovieByMovieName(@PathVariable("movieName") String movieName){
        return new ResponseEntity<>(service.getMoviesBymovieName(movieName),HttpStatus.OK);
    }
    
    @DeleteMapping(path = "/movie/{id}") //work
    public ResponseEntity <Void> deleteUser(@PathVariable("id") Integer id){
    service.deleteByMovieId	(id);
    return new ResponseEntity<Void>(HttpStatus.OK);
        
    }
    
    @RequestMapping(method=RequestMethod.PUT, value="/updatemovie/{id}")
    public ResponseEntity<Movie> updateDetails(@PathVariable("id") Integer id,@Valid @RequestBody Movie movie){
        return new ResponseEntity<>(service.updateDetails(id,movie), HttpStatus.OK);
    }
}












