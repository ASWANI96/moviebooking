
package com.infy.bookingservice;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class BookingService {

	@Autowired
	private BookingRepository bookrepo;
	@Autowired
	private ShowRepository showrepo;



	public Booking addBooking(Booking booking) throws Exception {
		
		String sts="Booked";

		Integer seatsBooked=booking.getSeatsBooked();
		Integer showid=booking.getShowID().getShowId();
		Optional <Show> show=showrepo.findById(showid);
		Float ticketPrice=show.get().getTicketPrice();
		Integer seatsAvailable=show.get().getSeatsAvailable();
		if(seatsAvailable<seatsBooked) {

			 

            throw new Exception("SEAT_UNAVAILABLE");
        }
		else {
			Integer remainingseats=seatsAvailable-seatsBooked;
			show.get().setSeatsAvailable(remainingseats);
			System.out.println(remainingseats);
			System.out.println(ticketPrice);
			Float amount=(seatsBooked*ticketPrice);
			booking.setAmount(amount);
			booking.setStatus(sts);
			return bookrepo.save(booking);
		}
		
	}




       public List<Booking> getBookings(){
		return (List<Booking>) bookrepo.findAll();
	}

	public Booking getBookingbyId(Integer id) {
		return bookrepo.findById(id).get();
	}

	public Booking deleteBooking(Integer id) {
		
		String sts="Cancelled";

		Booking booking=getBookingbyId(id);
		Integer seatsBooked=booking.getSeatsBooked();
		Show show=booking.getShowID();
		Integer seatsAvailable=show.getSeatsAvailable();
		Integer remainingSeats=(seatsAvailable+seatsBooked);
		System.out.println(remainingSeats);
		show.setSeatsAvailable(remainingSeats);
		booking.setStatus(sts);
		return bookrepo.save(booking);
	}

	public List<Show> getAllShows(){
		return (List<Show>) showrepo.findAll();
	}

	public Optional<Show> findShow(Integer id) {        
		Optional<Show> show = showrepo.findById(id);
		return show;
	}

	public Show addShow(Show show) {
		System.out.println(show.getMovieId().getMovieId());
		return showrepo.save(show);
	}

	public Show updateshowDetails(Integer id,Show show) {
		show.setShowId(id);
		return showrepo.save(show);
	}

	public Show getShow(Integer id) {
		return showrepo.findById(id).get();
	}

	public void deleteShow(Integer id) {      
		showrepo.deleteById(id);        
	}
	
	public List<Show> findShowByMovie(Integer movieId) {       
		List<Show> allshows = getAllShows();
		List<Show> shows = new ArrayList<>();
		for(Show show : allshows) {
			if(show.getMovieId().getMovieId().equals(movieId)) {
				shows.add(show);
			}
		}
		return shows;     
	}

	public List<Show> findShowByTheatre(Integer theatreId) {       
		List<Show> allshows = getAllShows();
		List<Show> shows = new ArrayList<>();
		for(Show show : allshows) {
			if(show.getTheatreId().getTheatreId().equals(theatreId)) {
				shows.add(show);
			}
		}
		return shows;     
	}

}
